
This program has been tested on Windows XP/7/10.


First, install the included OPTIMA fonts.

To use this program, run the travcalc305b.exe file.

If a file is reported missing, such as MSVCP71.dll, copy the file to your C:\Windows\System32 folder.  Then run again.



WARNING: I'm not responsible for any harm caused by using this software for any version of Traveller other than Mongoose Traveller 2nd Edition.

-Shawn
shawndriscoll@hotmail.com






The Traveller game in all forms is owned by Far Future Enterprises. Copyright 1977 - 2020 Far Future Enterprises. Traveller is a registered trademark of Far Future Enterprises.